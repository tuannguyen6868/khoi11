-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Apr 24, 2010 at 10:45 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `webbanmaytinh`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `admin`
-- 

CREATE TABLE `admin` (
  `Taikhoan` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `ten` varchar(50) NOT NULL,
  `nickyahoo` varchar(50) NOT NULL,
  `Trangthai` tinyint(4) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `sodt` varchar(50) NOT NULL,
  PRIMARY KEY  (`Taikhoan`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `admin`
-- 

INSERT INTO `admin` VALUES ('Admin', '123456', '', '', 0, '', '');
INSERT INTO `admin` VALUES ('Taicaibang', '12345', 'Do Ngoc Tai', 'tomandjerry', 1, 'tomandjerry@yahoo.com', '098765432');
INSERT INTO `admin` VALUES ('tien', '123456', 'nguyen hung tien', 'tienlay88', 1, 'tienlay88@yahoo.com', '01663823092');

-- --------------------------------------------------------

-- 
-- Table structure for table `cauhoibimat`
-- 

CREATE TABLE `cauhoibimat` (
  `Macauhoi` int(11) NOT NULL auto_increment,
  `Noidungcauhoi` varchar(200) NOT NULL,
  PRIMARY KEY  (`Macauhoi`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `cauhoibimat`
-- 

INSERT INTO `cauhoibimat` VALUES (2, 'Ban thich con so nao nhat?');
INSERT INTO `cauhoibimat` VALUES (3, 'Doi bong nao ban ghet nhat?');
INSERT INTO `cauhoibimat` VALUES (4, 'Cau thu nao xuat sac nhat?');

-- --------------------------------------------------------

-- 
-- Table structure for table `chitiethoadonban`
-- 

CREATE TABLE `chitiethoadonban` (
  `SoHD` int(11) NOT NULL auto_increment,
  `MaSP` int(11) NOT NULL,
  `Soluong` int(11) NOT NULL,
  `Dongia` float NOT NULL,
  PRIMARY KEY  (`SoHD`,`MaSP`),
  KEY `MaSP` (`MaSP`),
  KEY `SoHD` (`SoHD`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=128 ;

-- 
-- Dumping data for table `chitiethoadonban`
-- 

INSERT INTO `chitiethoadonban` VALUES (127, 92, 2, 5.199e+006);
INSERT INTO `chitiethoadonban` VALUES (126, 93, 5, 6.599e+006);
INSERT INTO `chitiethoadonban` VALUES (126, 57, 1, 4.29e+006);
INSERT INTO `chitiethoadonban` VALUES (126, 92, 1, 5.199e+006);
INSERT INTO `chitiethoadonban` VALUES (126, 86, 1, 7.602e+006);
INSERT INTO `chitiethoadonban` VALUES (125, 58, 2, 6.588e+006);
INSERT INTO `chitiethoadonban` VALUES (124, 74, 1, 123);
INSERT INTO `chitiethoadonban` VALUES (123, 74, 1, 1.23457e+007);
INSERT INTO `chitiethoadonban` VALUES (122, 74, 1, 1.23457e+007);
INSERT INTO `chitiethoadonban` VALUES (124, 57, 19, 4.29e+006);
INSERT INTO `chitiethoadonban` VALUES (120, 49, 1, 6.878e+006);

-- --------------------------------------------------------

-- 
-- Table structure for table `hang`
-- 

CREATE TABLE `hang` (
  `MaHang` int(11) NOT NULL auto_increment,
  `TenHang` varchar(50) NOT NULL,
  `MaLoaiHang` int(11) NOT NULL,
  `TrangThai` binary(1) NOT NULL,
  PRIMARY KEY  (`MaHang`),
  KEY `MaLoaiHang` (`MaLoaiHang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

-- 
-- Dumping data for table `hang`
-- 

INSERT INTO `hang` VALUES (2, 'LeNoVo', 1, 0x31);
INSERT INTO `hang` VALUES (4, 'Toshiba', 1, 0x31);
INSERT INTO `hang` VALUES (5, 'Apple', 1, 0x31);
INSERT INTO `hang` VALUES (7, 'Asus', 1, 0x31);
INSERT INTO `hang` VALUES (8, 'FBT', 1, 0x30);
INSERT INTO `hang` VALUES (10, 'Dell', 1, 0x31);
INSERT INTO `hang` VALUES (11, 'Vio', 1, 0x30);
INSERT INTO `hang` VALUES (12, 'FPT ', 3, 0x31);
INSERT INTO `hang` VALUES (13, 'HP', 3, 0x31);
INSERT INTO `hang` VALUES (14, 'Tiger', 3, 0x31);
INSERT INTO `hang` VALUES (19, 'HP', 1, 0x31);
INSERT INTO `hang` VALUES (21, 'IBM', 3, 0x31);

-- --------------------------------------------------------

-- 
-- Table structure for table `hinhthucthanhtoan`
-- 

CREATE TABLE `hinhthucthanhtoan` (
  `MaThanhToan` int(11) NOT NULL,
  `LoaiThanhToan` varchar(30) NOT NULL,
  PRIMARY KEY  (`MaThanhToan`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `hinhthucthanhtoan`
-- 

INSERT INTO `hinhthucthanhtoan` VALUES (1, 'Tra Bang Tien Mat');
INSERT INTO `hinhthucthanhtoan` VALUES (2, 'The');

-- --------------------------------------------------------

-- 
-- Table structure for table `hoadonban`
-- 

CREATE TABLE `hoadonban` (
  `SoHD` int(11) NOT NULL auto_increment,
  `NgayxulyHD` datetime NOT NULL,
  `TrangThai` binary(1) NOT NULL default '0',
  `NgaylapHD` datetime NOT NULL,
  `TenKH` varchar(50) default NULL,
  `EmailKH` varchar(100) default NULL,
  `DiachiKH` varchar(500) default NULL,
  `DienThoaiKH` varchar(30) default NULL,
  `MaKH` int(11) NOT NULL,
  `MaThanhToan` int(11) NOT NULL,
  PRIMARY KEY  (`SoHD`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=128 ;

-- 
-- Dumping data for table `hoadonban`
-- 

INSERT INTO `hoadonban` VALUES (127, '2010-04-27 00:00:00', 0x30, '2010-04-24 12:21:00', 'Nguyen Hung Tien', NULL, 'Ha Bac', '', 36, 2);
INSERT INTO `hoadonban` VALUES (120, '2010-04-24 00:00:00', 0x32, '2010-04-21 21:40:21', 'abc', NULL, 'abc', '1234567', 33, 2);
INSERT INTO `hoadonban` VALUES (124, '2010-04-29 00:00:00', 0x30, '2010-04-24 09:19:16', 'Nguyen Hung Tien', NULL, '', '', 36, 1);
INSERT INTO `hoadonban` VALUES (122, '2010-04-23 00:00:00', 0x30, '2010-04-22 17:38:08', 'adadadad', NULL, '', '', 33, 2);
INSERT INTO `hoadonban` VALUES (123, '2010-04-23 00:00:00', 0x30, '2010-04-22 17:38:50', 'Nguyen van tai', NULL, '', '', 33, 2);
INSERT INTO `hoadonban` VALUES (125, '2010-04-28 00:00:00', 0x31, '2010-04-24 09:22:20', 'Nguyen Hung Tien', NULL, '', '', 36, 2);
INSERT INTO `hoadonban` VALUES (126, '2010-04-30 00:00:00', 0x30, '2010-04-24 11:48:45', 'Nguyen Hung Tien', NULL, 'hanoi', '', 36, 2);

-- --------------------------------------------------------

-- 
-- Table structure for table `khachhang`
-- 

CREATE TABLE `khachhang` (
  `MaKH` int(11) NOT NULL auto_increment,
  `TenKH` varchar(50) NOT NULL,
  `TaiKhoan` varchar(50) NOT NULL,
  `MatKhau` varchar(50) NOT NULL,
  `DiaChi` varchar(150) NOT NULL,
  `DienThoai` varchar(15) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `GioiTinh` binary(1) NOT NULL,
  `TrangThai` binary(1) NOT NULL,
  `Macauhoi` int(11) NOT NULL,
  `Traloi` varchar(100) NOT NULL,
  PRIMARY KEY  (`MaKH`),
  UNIQUE KEY `TaiKhoan` (`TaiKhoan`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

-- 
-- Dumping data for table `khachhang`
-- 

INSERT INTO `khachhang` VALUES (33, 'Nguyen van tai', 'tai', '123', 'Ã iaadadad', '879444509999', 'tienlay88@yahoo.com', 0x31, 0x30, 2, '1');
INSERT INTO `khachhang` VALUES (34, 'nguyen thi nhung', 'nhung', '123', 'dadadad', '08987772222', 'dadaa@yahoo.com', 0x30, 0x31, 2, '5');
INSERT INTO `khachhang` VALUES (35, 'Nguyen Thanh Tam', 'taitubon', '123', 'Dan lap-Hong Bang', '233431156767', 'adc@yahoo.com', 0x31, 0x31, 2, '1');
INSERT INTO `khachhang` VALUES (36, 'Nguyen Hung Tien', 'bamanh', '123456', 'Thach That- Hatay', '123456789', 'adada@yahoo.com', 0x31, 0x31, 2, '1');
INSERT INTO `khachhang` VALUES (37, 'nguyen Van Tien', 'huyzoot', '123456', 'Binh da- hatay', '31310434343', 'b@yahoo.com', 0x31, 0x31, 2, '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `loaihang`
-- 

CREATE TABLE `loaihang` (
  `MaLoaiHang` int(11) NOT NULL auto_increment,
  `TenLoaiHang` varchar(50) NOT NULL,
  `TrangThai` binary(1) NOT NULL,
  PRIMARY KEY  (`MaLoaiHang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `loaihang`
-- 

INSERT INTO `loaihang` VALUES (1, 'Lap Top', 0x31);
INSERT INTO `loaihang` VALUES (3, 'MayTinhDeBan', 0x31);

-- --------------------------------------------------------

-- 
-- Table structure for table `sanpham`
-- 

CREATE TABLE `sanpham` (
  `MaSP` int(11) NOT NULL auto_increment,
  `TenSP` varchar(150) NOT NULL,
  `ThongTinSP` varchar(1000) NOT NULL,
  `HinhAnh` varchar(200) NOT NULL,
  `ThoiGianBH` tinyint(4) NOT NULL,
  `Gia` float NOT NULL,
  `NgayNhap` datetime NOT NULL,
  `SoLuong` int(11) NOT NULL,
  `XuatSu` varchar(50) NOT NULL,
  `TrangThai` binary(1) NOT NULL,
  `MaHang` int(11) NOT NULL,
  `TinhTrang` binary(1) NOT NULL,
  PRIMARY KEY  (`MaSP`),
  KEY `MaHang` (`MaHang`),
  KEY `MaSP` (`MaSP`),
  KEY `MaSP_2` (`MaSP`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=94 ;

-- 
-- Dumping data for table `sanpham`
-- 

INSERT INTO `sanpham` VALUES (49, 'Acer Aspire X1700 - 004 (Linux + Táº·ng USB 2GB) ', 'Intel Pentium Dual-Core E2200 (2*2.20GHz) / 1MB Cache / 1GB DDR / 160GB SATA HDD / DVDÂ±RW CardReader / VGA NVIDIA GF 7100 upto 256MB / Gigabit NIC / Keyboard + Mouse Optical - (khÃ´ng kÃ¨m mÃ n hÃ¬nh) ', '1700.jpg', 12, 6.878e+006, '2010-03-09 00:00:00', 15, 'USA', 0x31, 14, 0x00);
INSERT INTO `sanpham` VALUES (52, 'Acer eMachines EL1801 (Linux ) + Táº·ng USB 2GB ', 'Dual core E 5200 ( 2x2.5Ghz, 2M cache, FSB 800 ) Chipset Ndivia Geforce 7100 Chipset Memory 1GB DDRII - 667Mhz / 160GB SATA 7200rpm/ DVD-RW/ Graphics Ndivia Geforce 7100 Chipset Network Gigabit Ethernet/ 8 xUSB 2.0 Port /Card-reader Multi card Reader/ Audio Embedded high-definition audio Keyboard Optical Mouse / USB Keyboard Monitor Option OS Linux KhÃ´ng kÃ¨m mÃ n hÃ¬nh', '1801.jpg', 12, 5.213e+006, '2010-03-10 00:00:00', 15, 'China', 0x31, 14, 0x00);
INSERT INTO `sanpham` VALUES (53, 'HP - Pavilion G3318L( KJ424AA (PC DOS ) Táº·ng USB 2GB ', 'IntelÂ® PentiumÂ®Dual-Core E2180 (2*2.0GHz, 1MB L2 cache, 800MHz FSB, 64bit)/ Keyboard/Mouse /1GB DDR2/160GB SATA/IntelÂ® GMA 950 up to 128MB (Vista share)/6*USB2.0/ 1*PCI-Ex 16X/1*PCI-Ex 1X/0/100TX/DVD-RW /Surround 5.1/2*PCI/ without Monitor (KhÃ´ng bao gá»“m MÃ n hÃ¬nh)', '3318.jpeg', 12, 5.792e+006, '2010-03-10 00:00:00', 15, 'China', 0x31, 13, 0x00);
INSERT INTO `sanpham` VALUES (55, 'HP Pavilion Desktop A6618L - KF921AA (PC Dos ) + Táº·ng USB 2GB', 'Core 2 Duo E7200 (2*2.53GHz) / 3MB Cache /  2GB DDR2 /  320GB HDD /  DVDÂ±RW DL  / Card Reader VGA Intel GForce 9300SE Graphics 128MB / NIC+Modem / Keyboad  + Mouse  Wireless (KhÃ´ng bao gá»“m MÃ n hÃ¬nh) ', 'HPG3215L.jpg', 12, 1.0317e+007, '2010-03-09 00:00:00', 15, 'China', 0x31, 13, 0x00);
INSERT INTO `sanpham` VALUES (56, 'HP DX7510 E7500 (ND075AV)+Táº·ng USB 2GB', 'IntelÂ® Core 2 Duo Processor E7500 - 2.93 GHz (2 MB L2 cache, 1066 MHz FSB) / Intel Q33 Chipset / 1024 MB DDR3 / 250 GB Serial ATA / DVD-ROM / 22-in-1 Card Reader / Intel Graphics GMA4500 / PC-DOS', '3318.jpeg', 12, 9.412e+006, '2010-03-10 00:00:00', 15, 'China', 0x31, 13, 0x31);
INSERT INTO `sanpham` VALUES (57, 'BA - D431G25C - PC DOS + Táº·ng DVD Rom Samsung 16X SATA 	', 'Intel G31 chipset / Intel Celeron D430 (1.8GHz)/ DDR2 1.0GB DDR2 / HDD 250GB SATA / VGA 256MB Share Memory & Sound 6 channel & NIC onboard /Power 400W / Keyboard + Mouse Optical Siroko, (giÃ¡ khÃ´ng kÃ¨m mÃ n hÃ¬nh). Báº£o hÃ nh miá»…n phÃ­ táº¡i nÆ¡i sá»­ dá»¥ng 1 Ä‘á»•i 1 trong vÃ²ng 12 thÃ¡ng. ', 'SRK2.jpg', 15, 4.29e+006, '2010-03-10 00:00:00', 15, 'VietNam', 0x31, 12, 0x31);
INSERT INTO `sanpham` VALUES (58, 'BA - 752G25C2D/G41 - PC DOS + Táº·ng DVD Rom Samsung 16X SATA', 'IntelÂ® G41 Chipset/ Intel Core 2 Duo E7500 (2.93GHz)/ DDR2 2GB Bus 800Mhz/ HDD 250GB SATA/ VGA upto 512 share memory & sound 8 channel & NIC onboard/ Power 400W/ Keyboard + Muose Optical Siroko , (giÃ¡ khÃ´ng kÃ¨m mÃ n hÃ¬nh). Báº£o hÃ nh miá»…n phÃ­ táº¡i nÆ¡i sá»­ dá»¥ng 1 Ä‘á»•i 1 trong vÃ²ng 12 thÃ¡ng. ', 'SRK2.jpg', 12, 6.588e+006, '2010-03-09 00:00:00', 15, 'China', 0x31, 12, 0x31);
INSERT INTO `sanpham` VALUES (89, 'Lenovo ThinkCentre M57e ( 9948 - CTO ) - Win Vista Business + Táº·ng USB 2GB', 'Pentium Dual Core E2200 2*2.0GHz / 1M Cache / Chipset Intel 946 / 512MB DDR / 160GB HDD / DVDRom ComboVGA Intel GMA X3100 128MB Vram / Sound & NIC onboard / Keyboard + Mouse (khÃ´ng kÃ¨m mÃ n hÃ¬nh ) ', '1700.jpg', 12, 1.23457e+006, '2010-04-24 10:45:34', 0, 'China', 0x31, 21, 0x31);
INSERT INTO `sanpham` VALUES (90, 'Lenovo ThinkCentre M57e( 9948 - A39) - PC DOS+ Táº·ng USB 2GB ', 'Pentium Dual Core E2160 2*1.8GHz / 1M Cache / Chipset Intel 946 / 512MB DDR / 160GB HDD / DVD-CDRW Combo VGA Intel GMA X3100 128MB Vram / Sound & NIC onboard / Keyboard + Mouse(KhÃ´ng bao gá»“m MÃ n hÃ¬nh) ', 'PC IBM.jpg', 12, 7.24e+006, '2010-04-24 10:46:42', 0, 'USA', 0x31, 21, 0x31);
INSERT INTO `sanpham` VALUES (91, 'IBM-Lenovo Consumer H100-2BA(57058129) - (PC Dos) + Táº·ng USB 2GB', 'H100-2BA: Intel Core 2 Duo E2140 (2 x 1.6Ghz)/ 512Mb DDRAM /\r\n160GB HDD / DVD-WR (double-layer)/ Modem / Hi-Fi Speaker, Anti-\r\nBacteria Keyboard + Mouse, DOS (KhÃ´ng bao gá»“m MÃ n hÃ¬nh).', 'IBMH100.jpg', 12, 6.679e+006, '2010-04-24 10:48:54', 0, 'China', 0x31, 21, 0x31);
INSERT INTO `sanpham` VALUES (92, 'Siroko BA - 651G25E/G31 - PC DOS', 'IntelÂ® G31 Chipset Pentium E6500 Dual Core (2*2.93GHz)/1GB DDR2 Bus 800Mhz/HDD 250GB SATA/VGA upto 512 share memory & sound 8 channel & NIC onboard/ Power 400W/Keyboard + Mouse Optical Siroko, (giÃ¡ khÃ´ng kÃ¨m mÃ n hÃ¬nh)', 'SRK2.jpg', 12, 5.199e+006, '2010-04-24 10:51:52', 0, 'China', 0x31, 12, 0x31);
INSERT INTO `sanpham` VALUES (93, 'Siroko BA - 752G25C2D/G41', 'IntelÂ® G41 Chipset/ Intel Core 2 Duo E7500 (2.93GHz)/ DDR2 2GB Bus 800Mhz/ HDD 250GB SATA/ VGA upto 512 share memory & sound 8 channel & NIC onboard/ Power 400W/ Keyboard + Muose Optical Siroko , (giÃ¡ khÃ´ng kÃ¨m mÃ n hÃ¬nh). ', 'SRK2.jpg', 12, 6.599e+006, '2010-04-24 10:54:24', 0, 'USA', 0x31, 12, 0x31);
INSERT INTO `sanpham` VALUES (74, 'HP Compaq dx2355 (KM421AV) Táº·ng USB 2GB - ChÃ­nh hÃ£ng', 'AMD Athlon X2 240 (2x2.8) GHz/DDR2 1024MB PC2-6400/250 GB SATA 3G (3.0 Gb/sec) : 7200 rpm/DVD Player (read: up to 16x DVD-ROM, up to 40x CD-ROM)/Intergrated/Integrated 10/100 Base-T networking interface/2xUSB 2.0, 1xHeadphone, 1x Microphone/6 in 1 Card Reader/6-channel high-definition audio/Compaq USB keyboard (katydid), USB optical mouse /FreeDOS (khÃ´ng bao gá»“m mÃ n hÃ¬nh) ', '4710.jpg', 124, 123, '2010-03-04 00:00:00', 12, 'China', 0x31, 13, 0x31);
INSERT INTO `sanpham` VALUES (86, 'Lenovo IdeaCentre Q200 (5709-2743) - PC DOS + Táº·ng USB 2GB', 'E7300 (2x2.66GHz/2MB L2 Cache) / IntelG3 chipset 1GB DDR2 / 320GB HDD DVD Multiburner / DVMT Sound & Nic onboard ntel GMA3100Integrated 16-in-1 Bright-EyeCam/ Keyboard + Mouse ( KhÃ´ng kÃ¨m mÃ n hÃ¬nh ) ', 'h210.jpg', 12, 7.602e+006, '2010-04-24 09:36:28', 0, 'China', 0x31, 21, 0x31);

-- --------------------------------------------------------

-- 
-- Table structure for table `thongtinphanhoi`
-- 

CREATE TABLE `thongtinphanhoi` (
  `MaTin` int(11) NOT NULL auto_increment,
  `TieuDe` varchar(50) NOT NULL,
  `NgayDang` datetime NOT NULL,
  `NoiDung` varchar(1000) NOT NULL,
  `TrangThai` binary(1) NOT NULL default '0',
  `MaKH` int(11) NOT NULL,
  `MaSP` int(11) NOT NULL,
  PRIMARY KEY  (`MaTin`),
  KEY `MaSP` (`MaSP`),
  KEY `MaKH` (`MaKH`),
  KEY `MaSP_2` (`MaSP`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=192 ;

-- 
-- Dumping data for table `thongtinphanhoi`
-- 

INSERT INTO `thongtinphanhoi` VALUES (191, 'ngay chinh trung', '2010-04-24 10:25:51', 'chochet', 0x31, 36, 86);
INSERT INTO `thongtinphanhoi` VALUES (190, 'Ngay khong em', '2010-04-24 10:18:31', 'Cuoc song vat va', 0x30, 36, 87);
INSERT INTO `thongtinphanhoi` VALUES (188, 'Cuoc Song Co Nhieu y Nghia', '2010-04-24 10:06:27', 'Hoc tap song va lam viec theo tam guong ho chu tich', 0x30, 36, 74);
INSERT INTO `thongtinphanhoi` VALUES (189, 'Thang cao tao dap chet gio', '2010-04-24 10:07:05', 'IntelÂ® PentiumÂ® Dual-Core E2220 (2*2.4GHz, 1MB L2 , 800MHz FSB/383MB TurboCacheâ„¢ NVIDIAÂ® / Ram 1G / HDD 160G sata/ GeForceÂ® 7100 (share)6*USB2.0, Serial, IEEE1394 6xAudio jacks ', 0x31, 36, 50);
INSERT INTO `thongtinphanhoi` VALUES (186, 'Chat luong kha tot', '2010-04-24 10:00:15', 'May cua cong ty rat tot . Chung ta pai mua nhe', 0x31, 36, 74);
INSERT INTO `thongtinphanhoi` VALUES (187, 'Cuoc Song Co Nhieu y Nghia', '2010-04-24 10:04:44', 'Hoc tap song va lam viec theo tam guong ho chu tich', 0x31, 36, 74);

-- --------------------------------------------------------

-- 
-- Table structure for table `tintuc`
-- 

CREATE TABLE `tintuc` (
  `Matinmoi` int(11) NOT NULL auto_increment,
  `Tieudetin` varchar(100) NOT NULL,
  `Ngayduatin` datetime NOT NULL,
  `Noidungtin` varchar(5000) NOT NULL,
  `Anh` varchar(250) NOT NULL,
  `Nguon` varchar(100) NOT NULL,
  `Trangthai` binary(1) NOT NULL,
  `Kieutin` tinyint(4) NOT NULL,
  PRIMARY KEY  (`Matinmoi`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

-- 
-- Dumping data for table `tintuc`
-- 

INSERT INTO `tintuc` VALUES (24, 'ThÃ´ng bÃ¡o tuyá»ƒn dá»¥ng thÃ¡ng 02/2010', '2010-03-10 00:00:00', 'PhÃºc Anh luÃ´n mong muá»‘n Ä‘Æ°á»£c há»£p tÃ¡c vá»›i cÃ¡c Báº¡n tráº» nÄƒng Ä‘á»™ng, nhiá»‡t tÃ¬nh, ham há»c há»i vÃ  Ä‘áº·c biá»‡t yÃªu thÃ­ch CNTT. Äáº¿n vá»›i PhÃºc Anh nghÄ©a lÃ  Báº¡n Ä‘áº¿n vá»›i má»™t mÃ´i trÆ°á»ng lÃ m viá»‡c chuyÃªn nghiá»‡p, nÄƒng Ä‘á»™ng vÃ  cÃ³ cÆ¡ há»™i Ä‘Æ°á»£c kháº³ng Ä‘á»‹nh báº£n thÃ¢n.\r\n\r\nPhÃºc Anh - Má»™t thÆ°Æ¡ng hiá»‡u cÃ³ uy tÃ­n trong lÄ©nh vá»±c CNTT táº¡i Viá»‡t Nam - NhÃ  phÃ¢n phá»‘i, Ä‘áº¡i lÃ½ chÃ­nh thá»©c cÃ¡c sáº£n pháº©m cá»§a cÃ¡c hÃ£ng danh tiáº¿ng trÃªn tháº¿ giá»›i.\r\n\r\nHá»‡ thá»‘ng PhÃºc Anh bao gá»“m 02 CÃ´ng ty:\r\n\r\n- CÃ´ng ty TNHH Ká»¹ Nghá»‡ PhÃºc Anh (há»‡ thá»‘ng bÃ¡n láº»).\r\n\r\n- CÃ´ng ty CP PhÃ¢n phá»‘i PhÃºc Anh (há»‡ thá»‘ng bÃ¡n phÃ¢n phá»‘i).\r\n\r\nPhÃºc Anh khÃ´ng ngá»«ng nÃ¢ng cao cháº¥t lÆ°á»£ng sáº£n pháº©m, dá»‹ch vá»¥ cÅ©ng nhÆ° trÃ¬nh Ä‘á»™ chuyÃªn mÃ´n cá»§a nhÃ¢n viÃªn Ä‘á»ƒ Ä‘em Ä‘áº¿n sá»± hÃ i lÃ²ng cho toÃ n thá»ƒ QuÃ½ khÃ¡ch hÃ ng.\r\n\r\nPhÃºc Anh luÃ´n mong muá»‘n Ä‘Æ°á»£c há»£p tÃ¡c vá»›i cÃ¡c Báº¡n tráº» nÄƒng Ä‘á»™ng, nhiá»‡t tÃ¬nh, ham há»c há»i vÃ  Ä‘áº·c biá»‡t yÃªu thÃ­ch CNTT. Äáº¿n vá»›i PhÃºc Anh nghÄ©a lÃ  Báº¡n Ä‘áº¿n vá»›i má»™t mÃ´i trÆ°á»ng lÃ m viá»‡c chuyÃªn nghiá»‡p, nÄƒng Ä‘á»™ng vÃ  cÃ³ cÆ¡ há»™i Ä‘Æ°á»£c kháº³ng Ä‘á»‹nh báº£n thÃ¢n.\r\n\r\nHiá»‡n nay PhÃºc Anh Ä‘ang cÃ³ nhu cáº§u tuyá»ƒn dá»¥ng cho cÃ¡c vá»‹ trÃ­ sau:\r\n\r\n1. NhÃ¢n viÃªn váº­n chuyá»ƒn (ThÃ´ng tin chi tiáº¿t xem táº¡i Ä‘Ã¢y)\r\n\r\n2. NhÃ¢n viÃªn Marketing (ThÃ´ng tin chi tiáº¿t xem táº¡i Ä‘Ã¢y)\r\n\r\n3. NhÃ¢n viÃªn chÄƒm sÃ³c khÃ¡ch hÃ ng (ThÃ´ng tin chi tiáº¿t xem táº¡i Ä‘Ã¢y)\r\n\r\n4. NhÃ¢n viÃªn bÃ¡n hÃ ng vÃ  giá»›i thiá»‡u sáº£n pháº©m (ThÃ´ng tin chi tiáº¿t xem táº¡i Ä‘Ã¢y)', 'resize_10_tuyendung.jpg', 'Phuc Anh', 0x31, 2);
